fn main() {
    let x = [0; 8];
}
