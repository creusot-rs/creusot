fn max_int() -> usize {
    usize::MAX
}
