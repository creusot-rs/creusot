extern crate creusot_contracts;
use creusot_contracts::*;
#[requires(exampleParameter == exampleParameter)]
fn example(exampleParameter: bool) {}
