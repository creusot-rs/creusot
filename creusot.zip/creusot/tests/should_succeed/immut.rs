fn main() {
    let mut a = 10;
    let b = &mut a;
    let c: &u32 = b;
}
