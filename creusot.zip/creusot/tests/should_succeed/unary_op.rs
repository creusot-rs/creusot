// SHOULD_SUCCEED: parse-print
// Simple check that unary operators can be translated
fn main() {
    assert!(!false);
}
