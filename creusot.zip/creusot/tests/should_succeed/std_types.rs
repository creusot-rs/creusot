// SHOULD_SUCCEED: parse-print
struct MyType(Option<u32>);

fn x(x: MyType) {}

fn main() {}
