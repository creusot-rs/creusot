fn uses_concrete_instance(x: (u32, u32), y: (u32, u32)) -> bool {
    x < y
}

fn main() {}
